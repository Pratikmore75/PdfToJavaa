package pdfToExcel;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
//matcher matches the given input with the pattern
import java.util.regex.Matcher;
//Pattern class compiles the given regex and returns the instance of the Pattern.
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
//used for text extraction
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class data {

    public static void main(String[] args) {
    	//file location
        File file = new File("C:\\Users\\USER\\Desktop\\Placement\\AmritaBose_Resume.pdf");
        String excelFilePath = "C:\\Users\\USER\\Desktop\\Placement\\AmritaBose_Resume_Extracted.xls";
        
     /*
		// Load PDF file and extract text
        PDDocument document = PDDocument.load(new FileInputStream(pdfFilePath));
        PDFTextStripper stripper = new PDFTextStripper();
        String text = stripper.getText(document);

 

        // Extract specific keywords from text
        String name = extractKeyword(text, "Name:");
        String phone = extractKeyword(text, "Phone:");
        List<String> skills = extractSkills(text);
        
        // Write results to Excel file
        XSSFWorkbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Resume");

        
        
        Row row = sheet.createRow(0);

 

        Cell cell = row.createCell(0);
        cell.setCellValue("Name");

 

        cell = row.createCell(1);
        cell.setCellValue("Phone");

 

        cell = row.createCell(2);
        cell.setCellValue("Skills");

 

        row = sheet.createRow(1);

 

        cell = row.createCell(0);
        cell.setCellValue(name);

 

        cell = row.createCell(1);
        cell.setCellValue(phone);

 

        cell = row.createCell(2);
        cell.setCellValue(String.join(",", skills));*/
        
        // Write results to Excel file
        XSSFWorkbook workbook1 = new XSSFWorkbook();
        //Sheet sheet = workbook.createSheet("Resume");
        
        
        
        //keywords to be searched
        String[] keywords = {"Java", "Python","java","S3","EC2","aws","cloud","azure","SQL"};

        try (PDDocument document1 = PDDocument.load(file)) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text1 = pdfStripper.getText(document1);
            
            // \b --> boundary \w for word
            Pattern emailPattern = Pattern.compile("\\b[\\w.%-]+@[\\w.-]+\\.[A-Z]{2,4}\\b", Pattern.CASE_INSENSITIVE);
            Matcher emailMatcher = emailPattern.matcher(text1);

            while (emailMatcher.find()) {
                System.out.println("Email found: " + emailMatcher.group());
                // Write workbook to Excel file
                FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                workbook1.write(outputStream);
                workbook1.close();
                outputStream.close();
            }
            
            // \d for digits
            Pattern phonePattern = Pattern.compile("\\b\\d{10}\\b"); //for 10 digits
            Pattern phonePattern1 = Pattern.compile("\\b\\d{12}\\b"); // for 10 digits
            Matcher phoneMatcher = phonePattern.matcher(text1);
            Matcher phoneMatcher1 = phonePattern1.matcher(text1);

            while (phoneMatcher.find()) {
                System.out.println("Phone number found: " + phoneMatcher.group());
            	// Write workbook to Excel file
                FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                workbook1.write(outputStream);
                workbook1.close();
                outputStream.close();
            }
            while (phoneMatcher1.find()) {
                System.out.println("Phone number found: " + phoneMatcher1.group());
                // Write workbook to Excel file
                FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                workbook1.write(outputStream);
                workbook1.close();
                outputStream.close();
            }
            for (String keyword : keywords) {
                Pattern keywordPattern = Pattern.compile("\\b" + keyword + "\\b", Pattern.CASE_INSENSITIVE);
                Matcher keywordMatcher = keywordPattern.matcher(text1);

                if (keywordMatcher.find()) {
                    System.out.println("Keyword '" + keyword + "' found");
                 // Write workbook to Excel file
                    FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                    workbook1.write(outputStream);
                    workbook1.close();
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	private static List<String> extractSkills(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	private static String extractKeyword(String text, String string) {
		// TODO Auto-generated method stub
		return null;
	}
}